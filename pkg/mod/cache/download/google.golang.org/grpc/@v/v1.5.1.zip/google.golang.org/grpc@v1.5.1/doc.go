/*
Package grpc implements an RPC system called gRPC.

See grpc.io for more information about gRPC.
*/
package grpc // import "google.golang.org/grpc"
